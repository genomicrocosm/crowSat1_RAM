#!/bin/sh

echo $SHELL
hostname
cat /proc/cpuinfo
free


